export const proxy = 'https://cors-anywhere.herokuapp.com/';
export const key = 'd8148679005a18bb3672ffc4c1e72492';
