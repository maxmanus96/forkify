import uniqid from 'uniqid';

export default class List {
    constructor(){
        this.items = [];
    }

    addItem (count, unit, ingredient) {
        const item = {
            id: uniqid(),
            count,
            unit,
            ingredient // UNIQUE ID genratoron github also, another package by gtihub check
            //npm install fractional --save
            //npm install uniqid --save
        }
        this.items.push(item);
        return item;
    }

    deleteItem(id){
        const index = this.items.findIndex(el => el.id === id);
        // [2,4,8] splice(1,2) --> returns 4,8 original array is [2] // MUTATE, 1.indexten 1 element
        // [2,4,8] slice(1,2) --> returns 4, original array is [2,4,8] // NOT CHANGE 1. indexten söylenene indekse kadar manasına geliyor.
        return this.items.splice(index, 1); // index te yer alan 1 elemanı sil.
    }

    updateCount(id, newCount){
        this.items.find(el => el.id).count = newCount;
    }
}